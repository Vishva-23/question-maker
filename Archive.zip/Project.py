## Saving file name, Number of questions needed
###
### Given a master question bank file programs picks randomly no. of questions specified by the user and saves it as a separate text file
import random
# To generate a random number list which number questions will be taken for preparing the new test file
list=[]
print "Enter the questions needed"
for i in range(5):
    r=random.randint(1,20)
    if r not in list:
        list.append(r)

newlist=[]
## Opens the master file and picks the random numbered questions and formats it
fileopen = open("Masterfile.txt","r")
readdata=fileopen.readlines()
for datalength in range(len(readdata)):
    if readdata[datalength].find("Question") !=-1:
        newlist.append(readdata[datalength:datalength+5])
print len(newlist)
data =[]
for quiz in range(len(list)):
    print list[quiz]
    res = "Question" + str(quiz+1)
    data.append(str(newlist[list[quiz]-1]).replace('Question', res))
    print data
filewrite = open(r'C:\Users\ag\PycharmProjects\Vishwa\samplefile.txt','w')
filewrite.writelines(["%s\n" % item for item in data])
filewrite.close()
## Converts it to HTML
contents = open(r'C:\Users\ag\PycharmProjects\Vishwa\samplefile.txt',"r")
with open("samplequestions.html", "w") as e:
    e.write("<thead>" + "SAMPLE QUESTION PAPAER WITH 4 QUESTIONS" + "</thead> <br>\n")
    for lines in contents.readlines():
        e.write("<pre>" + lines + "</pre> <br>\n")
e.close()